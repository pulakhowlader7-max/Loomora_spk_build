"""cap add android এর পরে চলে: আইকন বসায়, রঙ ঠিক করে, ক্যামেরা পারমিশন যোগ করে।"""
import os, re, shutil, sys

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = os.path.join(root, 'android', 'app', 'src', 'main', 'res')
manifest = os.path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml')

if not os.path.isdir(res):
    sys.exit('android/app/src/main/res পাওয়া যায়নি')

# 1) আইকন
src = os.path.join(root, 'resources', 'android')
for d in os.listdir(src):
    sp = os.path.join(src, d)
    if os.path.isdir(sp):
        dp = os.path.join(res, d)
        os.makedirs(dp, exist_ok=True)
        for f in os.listdir(sp):
            shutil.copy2(os.path.join(sp, f), os.path.join(dp, f))

# 2) adaptive আইকনের ব্যাকগ্রাউন্ড রঙ
color = open(os.path.join(src, 'bgcolor.txt')).read().strip()
vals = os.path.join(res, 'values')
os.makedirs(vals, exist_ok=True)
with open(os.path.join(vals, 'ic_launcher_background.xml'), 'w') as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
            '    <color name="ic_launcher_background">%s</color>\n</resources>\n' % color)

# 3) ক্যামেরা (ছবি তোলার জন্য) পারমিশন
m = open(manifest, encoding='utf-8').read()
if 'android.permission.CAMERA' not in m:
    add = ('    <uses-permission android:name="android.permission.CAMERA" />\n'
           '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n')
    m = m.replace('</manifest>', add + '</manifest>')
    open(manifest, 'w', encoding='utf-8').write(m)
print('patch ok')
