/* Android (Capacitor) অ্যাপে ফাইল সেভ/শেয়ার সাপোর্ট। ব্রাউজারে এটি কিছুই করে না। */
(function () {
  try {
    var C = window.Capacitor;
    if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
    var blobs = {};
    var origCreate = URL.createObjectURL.bind(URL);
    URL.createObjectURL = function (obj) {
      var u = origCreate(obj);
      try { if (obj instanceof Blob) blobs[u] = obj; } catch (e) {}
      return u;
    };
    function toast(t) {
      try {
        var d = document.createElement('div');
        d.textContent = t;
        d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#121a2e;color:#fff;padding:10px 16px;border-radius:12px;z-index:99999;font-size:14px;max-width:80%;text-align:center';
        document.body.appendChild(d);
        setTimeout(function () { d.remove(); }, 2600);
      } catch (e) {}
    }
    function saveBlob(blob, name) {
      var P = C.Plugins || {};
      if (!P.Filesystem || !P.Share) { toast('সেভ করা গেল না'); return; }
      var fr = new FileReader();
      fr.onload = function () {
        var b64 = String(fr.result).split(',')[1] || '';
        P.Filesystem.writeFile({ path: name, data: b64, directory: 'CACHE' })
          .then(function (r) {
            return P.Share.share({ title: name, url: r.uri, dialogTitle: 'ফাইল সেভ বা শেয়ার করুন' });
          })
          .catch(function (e) {
            var m = String((e && e.message) || e || '');
            if (!/cancel/i.test(m)) toast('ফাইল সেভ হয়নি');
          });
      };
      fr.readAsDataURL(blob);
    }
    var origClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      var a = this;
      try {
        if (a.hasAttribute('download') && /^blob:/.test(a.href) && blobs[a.href]) {
          saveBlob(blobs[a.href], a.getAttribute('download') || 'file');
          return;
        }
      } catch (e) {}
      return origClick.apply(this, arguments);
    };
  } catch (e) {}
})();
